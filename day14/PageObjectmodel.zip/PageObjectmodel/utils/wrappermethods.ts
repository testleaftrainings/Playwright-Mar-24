import { Page } from "playwright";

abstract class PlaywrightWrapper{

    page:Page

    constructor(page:Page){
        this.page=page
    }

    async loadUrl(url:string){
        await this.page.goto(url);
    }

    async type(locator:string,testData:string){
        await this.page.locator(locator).fill(testData)
    }

    async typeAndEnter(locator:string,testData:string){
     //   await this.page.locator(locator).clear();
        await this.page.locator(locator).fill(testData)
        await this.page.keyboard.press('Enter');
    }

    async click(locator:string){
        await this.page.locator(locator).click({timeout:50000})
    }

    async getTitle():Promise<string>{
        await this.page.waitForLoadState('load')
         return await this.page.title();        
    }

    async getText(locatorValue:string):Promise<string>{
      return  await this.page.getByText(locatorValue).innerText();
    }

  async storageState(pathValue:string){
      await this.page.context().storageState({path:pathValue})
   }

   async clickwithtext(locatorValue:string){
    await this.page.getByText(locatorValue).click();
   }
}

export {PlaywrightWrapper}
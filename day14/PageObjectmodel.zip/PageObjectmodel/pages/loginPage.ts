import { Page } from "playwright";
import { PlaywrightWrapper } from "../utils/wrappermethods";

export class LoginPage extends PlaywrightWrapper{

 url:string
usernamefield:string

  constructor(page:Page){
      super(page);
     this.url='http://www.leaftaps.com/opentaps'
    // this.usernamefield="#username";
  }

   async doLogin(username:string,password:string){
    await this.loadUrl(this.url)
    await this.type("#username",username);
    await this.type("#password",password)
    await this.click(".decorativeSubmit");
    await this.storageState("./storageCookies.json")
   }







}
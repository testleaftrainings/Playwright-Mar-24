import { Page } from "playwright";
import { LoginPage } from "./loginPage";

export class HomePage extends LoginPage{


    constructor(page:Page){
        super(page)
    }

    async clickCrm(){
        await this.clickwithtext("CRM/SFA");
      }





}
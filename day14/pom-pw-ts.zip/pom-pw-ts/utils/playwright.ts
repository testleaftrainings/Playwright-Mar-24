import { hr } from "@faker-js/faker";
import { Page, test, expect, BrowserContext } from "@playwright/test";
import { TIMEOUT } from "dns";
import { hasRestParameter, isMinusToken } from "typescript";


export abstract class PlaywrightWrapper {

    readonly page: Page;
    readonly context: BrowserContext
    index: number
    constructor(page: Page, context: BrowserContext) {
        this.page = page;
        this.context = context;
    }
    /*
    This function types on the given element textbox after clearing the existing text
    @page: The page object to be passed
    @locator: The element locator
    @name: Name of the element
    @data: Data to be typed
    */
    async type(locator: string, name: string, data: string) {
        await test.step(`Textbox ${name} filled with data: ${data}`, async () => {
            //  await this.page.locator(locator).clear();
            await this.page.locator(locator).fill(data);

        });
    }
    /*
    This function types on the given element textbox and press <ENTER> after clearing the existing text
    @page: The page object to be passed
    @locator: The element locator
    @name: Name of the element
    @data: Data to be typed
    */
    async typeAndEnter(locator: string, name: string, data: string) {
        await test.step(`Textbox ${name} filled with data: ${data}`, async () => {

            await this.page.locator(locator).clear();
            await this.page.locator(locator).fill(data);
            await this.page.keyboard.press("Enter");

        });
    }
    /*
    This function clicks on the given element textbox
    @page: The page object to be passed
    @locator: The element locator
    @name: Name of the element
    */
    async click(locator: string, name: string, type: string) {
        await test.step(`The ${type} ${name} clicked`, async () => {
            await this.page.locator(locator).click();
        });
    }
    async storeState(path: string) {
        await this.page.context().storageState({ path: path })
    }
    async loadApp(url: string) {
        try {
            await test.step(`The URL ${url} loaded`, async () => {
                await this.page.goto(url, { timeout: 60000 }); // Increased timeout
            });
        } catch (error) {
            console.error('Error loading the page:', error);
        }
    }
    async getInnerText(locator: string): Promise<string> {
        return await this.page.locator(locator).innerText();
    }
    async getText(locator: string): Promise<string> {
        return await this.page.locator(locator).inputValue();

    }
    async getTitle(): Promise<string> {
        return await this.page.title();
    }

    async multipleWindowsCount(): Promise<number> {
        const windowslength = this.page.context().pages().length;
        return windowslength;
    }

    // async fillwithDelay(locator:string ,inputValues:string){
    //     await this.page.delayedFill(locator,inputValues)
    // }
   
    // async clickwithDelay(locator:string){
    //     await this.page.clickAndDelay(locator);
        
    //}
    async switchToWindowWithTitle(windowTitle: string) {
        //const context = this.page.context();
        const newPagePromise = this.context.waitForEvent('page');
        const windows = this.context.pages();
        for (const window of windows) {
            const title = await window.title();
            if (title === windowTitle) {
                await window.bringToFront();
                return window;
            }
        }
    }

    async acceptAlert(data: string) {
        const dialog = await this.page.waitForEvent('dialog');
        if (dialog.type() === 'alert') {
            dialog.message();
            await dialog.accept(data);
        }
        else {
        } throw new Error('No alert present');

    }

    //i:number;
    async clickinFrame(frameLocator: string, locator: string, name: string, type: string, index: number) {
        await test.step(`The ${type} ${name} clicked`, async () => {
            const frameCount = 1;
            await this.page.locator(frameLocator).count();
            if (frameCount > 0) {
                await this.page.frameLocator(frameLocator).locator(locator).nth(index).click();
            } else {
                await this.page.locator(locator).click();
            }
        })
    }
    async typeinFrame(flocator: string, locator: string, name: string, data: string) {
        await test.step(`Textbox ${name} filled with data: ${data}`, async () => {
            const frameCount = 1;
            if (frameCount > 0) {
                await this.page.frameLocator(flocator).locator(locator).clear();
                await this.page.frameLocator(flocator).locator(locator).fill(data);
                await this.page.keyboard.press("Enter");
            } else {
                await this.page.locator(locator).clear();
                await this.page.locator(locator).fill(data);
                await this.page.keyboard.press("Enter");
            }
        });
    }

}
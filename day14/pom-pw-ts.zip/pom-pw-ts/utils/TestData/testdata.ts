export interface LeadDetails {    
    lastName: string;
    firstName:string
    companyName: string;
  }
import { test, expect } from '../../customFixtures/leadFixtures';


test(`Login to SF`, async ({ sflogin }) => {
  test.setTimeout(120000)
  const title = await sflogin.getTitle();
  console.log(title)


})

